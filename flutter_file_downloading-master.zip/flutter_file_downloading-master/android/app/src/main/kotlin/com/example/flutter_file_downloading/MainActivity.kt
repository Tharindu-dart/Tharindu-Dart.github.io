package com.example.flutter_file_downloading

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
