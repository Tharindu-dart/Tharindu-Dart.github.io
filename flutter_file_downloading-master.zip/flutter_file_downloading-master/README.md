# Flutter File Downloading

This snippet code is regarding how to make file downloading with progress event.

Watch Video : https://youtu.be/j3kDocLnKLY


## Libraries Required
1. http:
2. provider:
3. permission_handler:
4. path_provider:
